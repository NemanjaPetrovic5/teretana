from flask import Flask, render_template, flash, redirect, url_for, request, session, jsonify
from pymongo import MongoClient
from flask_mail import Mail
from flask_mail import Message
from flask_uploads import UploadSet, IMAGES, configure_uploads
from bson import ObjectId
from datetime import datetime
import hashlib, time, string
import os
import secrets
import mysql.connector
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, SelectField, IntegerField, FileField, TextAreaField
from wtforms.validators import DataRequired, Length, Email, EqualTo
from wtforms.widgets import html5
from flask_wtf.file import FileField, FileAllowed
from wtforms.fields.html5 import DateField
from wtforms import Form

app = Flask(__name__)
app.config['SECRET_KEY'] = 'pSkJHDRJNMNv9X9Fb83KXJf8u8'
UPLOAD_FOLDER = 'src/static/img/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

class registracijaForm(FlaskForm):
	username = StringField(validators=[DataRequired(), Length(min=2, max=20)], render_kw={"placeholder": "Username"})
	ime_prezime = StringField(validators=[DataRequired(), Length(min=2, max=20)], render_kw={"placeholder": "Ime i prezime"})
	email = StringField(validators=[DataRequired(), Email()], render_kw={"placeholder": "Email adresa"})
	godina_rodjenja = IntegerField('Godina rodjenja', widget=html5.NumberInput(), render_kw={"placeholder" : "Godina rodjenja"})
	password = PasswordField(validators=[DataRequired()], render_kw={"placeholder": "Password"})
	confirm_password = PasswordField(validators=[DataRequired(), EqualTo('password')], render_kw={"placeholder": "Confirm password"})
	telefon = StringField(validators=[DataRequired(), Length(min=2, max=20)], render_kw={"placeholder": "Broj telefona"})
	slika = FileField("Profile photo", validators=[FileAllowed(['jpg', 'png'])])
	submit = SubmitField('Registruj se', render_kw={"id": "reg"})


class loginForm(FlaskForm):
	username = StringField(validators=[DataRequired()], render_kw={"placeholder": "Username"})
	password = PasswordField(validators=[DataRequired()], render_kw={"placeholder": "Password"})
	submit = SubmitField('Login')


class admin_loginForm(FlaskForm):
	username = StringField(validators=[DataRequired()], render_kw={"placeholder": "Username"})
	password = PasswordField(validators=[DataRequired()], render_kw={"placeholder": "Password"})
	submit = SubmitField('Login')


class zakazivanjeForm(FlaskForm):
	z_ime_prezime = StringField(validators=[DataRequired(), Length(min=2, max=30)], render_kw={"placeholder": "Ime i prezime"})
	z_email = StringField(validators=[DataRequired(), Email()], render_kw={"placeholder": "Email adresa"})
	z_telefon = StringField(validators=[DataRequired(), Length(min=2, max=30)], render_kw={"placeholder": "Broj telefona"})
	z_submit = SubmitField('Zakazi trening')


class dodajPaket(FlaskForm):
	naziv = StringField(validators=[DataRequired()], render_kw={"placeholder": "Naziv"})
	slika = FileField("Slika paketa", validators=[FileAllowed(['jpg', 'png']),DataRequired()])
	opis = StringField(validators=[DataRequired(), Length(min=2)], render_kw={"placeholder": "Opis"})
	cena = StringField(validators=[DataRequired(), Length(min=1, max=100)], render_kw={"placeholder": "Cena"})
	submit = SubmitField('Dodaj paket')


# MAIL konfiguracija
app.config.update(
	MAIL_SERVER='smtp.gmail.com',
	MAIL_PORT=465,
	MAIL_USE_SSL=True,
	MAIL_USERNAME = "srbwebshop@gmail.com",
	MAIL_PASSWORD = "bfmhdzpt"
	)

mail = Mail(app)

mydb = mysql.connector.connect(
	host="localhost",
	user="root",
	password="",
	database="teretana2"
    )


@app.route('/', methods=['POST', 'GET'])
def index():
	login = loginForm()
	zakazivanje = zakazivanjeForm()

	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM paketi")
	paketi = mc.fetchall()

	return render_template('index.html', login=login, zakazivanje=zakazivanje, paketi=paketi)


@app.route('/register', methods=['POST', 'GET'])
def register():
	form = registracijaForm()

	if form.validate_on_submit():

		korisnicko_ime = form.username.data

		mc = mydb.cursor()
		mc.execute(f"SELECT id FROM users WHERE username = '{korisnicko_ime}'")
		rez = mc.fetchall()

		if rez:
			flash('Korisnicko ime je zauzeto.')
			return render_template('register.html',  form=form)

		if form.slika.data is None:
			putanja = "/static/img/korisnici/default.png"

		hash_pw = hashlib.sha256(form.password.data.encode())
		password_hashed = hash_pw.hexdigest()
		ime_prezime = form.ime_prezime.data
		email = form.email.data
		godina_rodjenja = form.godina_rodjenja.data
		password = password_hashed
		telefon = form.telefon.data
		file = form.slika.data
		registrovan = time.strftime("%d.%m.%Y %H:%M")
		
		if file:
			filename = korisnicko_ime + ".jpg"
			file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
			putanja = f'/static/img/{filename}'
	
		
		mc = mydb.cursor()
		mc.execute(f"INSERT INTO users VALUES(null, '{korisnicko_ime}', '{ime_prezime}', '{email}','{godina_rodjenja}','{password}','{telefon}','{putanja}','{registrovan}' ) ")
		mydb.commit()
		
		session['usr'] = korisnicko_ime
	
		flash('Uspesno ste se registrovali!')
		return redirect(url_for('index'))
	return render_template('register.html',  form=form)



@app.route('/login', methods=['POST'])
def login():
	login = loginForm()
	
	if 'usr' in session:
		return redirect(url_for('index'))
	
	hash_pw = hashlib.sha256(login.password.data.encode())
	password_hashed = hash_pw.hexdigest()
	username = request.form['username']
	
	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM users where username='{username}'")
	korisnik = mc.fetchall()
	
	if len(korisnik) == 0:
		flash("Korisnik sa tim username ne postoji")
		return redirect(url_for('index'))
	if korisnik[0][5] != password_hashed:
		flash("Ne poklapaju se sifre")
		return redirect(url_for('index'))
	else:
		session['usr'] = username
		flash(f'Ulogovali ste se kao korisnik {username}')
		
	return redirect(url_for('index'))



@app.route('/logout')
def logout():
	if "usr" in session:
		session.pop('usr', None)
		return redirect(url_for('index'))
	else: 
		flash("Morate se ulogovati!")
		return redirect(url_for('index'))



@app.route('/admin', methods=['POST', 'GET'])
def admin():
	if 'admin' in session:
		return redirect(url_for('admin_panel'))

	admin_forma = admin_loginForm();

	if admin_forma.validate_on_submit():
		hash_pw = hashlib.sha256(admin_forma.password.data.encode())
		password_hashed = hash_pw.hexdigest()
		username = request.form['username']
		mc = mydb.cursor()
		mc.execute(f"SELECT * FROM admins where username='{username}'")
		admin = mc.fetchall()
		if len(admin) == 0:
			flash("Korisnik sa tim username ne postoji")
			return redirect(url_for('admin'))
		if admin[0][2] != password_hashed:
			flash("Ne poklapaju se sifre")
			return redirect(url_for('admin'))
		else:
			session['admin'] = username
			flash('Ulogovali ste se kao admin')
			
			return redirect(url_for('admin_panel'))
	return render_template("admin_login.html", admin=admin_forma)



@app.route('/admin/logout')
def admin_logout():
	if "admin" in session:
		session.pop('admin', None)
		return redirect(url_for('admin'))
	else: 
		flash("Vise niste ulogovani kao admin!")
		return redirect(url_for('admin'))


@app.route('/admin/panel', methods=['POST', 'GET'])
def admin_panel():
	if "admin" not in session:
		flash("Morate se ulogovati kao admin!")
		return redirect(url_for('admin'))

	form = dodajPaket()

	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM users")
	res = mc.fetchall()

	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM paketi")
	rez = mc.fetchall()

	mc = mydb.cursor()
	mc.execute(f"SELECT korpa.id ,korpa.korisnik_username,users.email,users.telefon, paketi.naziv,paketi.opis,paketi.cena FROM korpa LEFT JOIN paketi ON korpa.paket_id = paketi.id LEFT JOIN users ON korpa.korisnik_username = users.username")
	trening = mc.fetchall()

	mc = mydb.cursor()
	mc.execute(f"SELECT zakazani_paketi.id ,zakazani_paketi.korisnik_username,zakazani_paketi.email,zakazani_paketi.telefon, paketi.naziv,paketi.opis,paketi.cena FROM zakazani_paketi LEFT JOIN paketi ON zakazani_paketi.paketi_id = paketi.id")
	trening2 = mc.fetchall()

	naziv = form.naziv.data
	file = form.slika.data
	opis = form.opis.data
	cena = form.cena.data
	
	if file:
		filename = naziv + ".jpg"
		file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
		putanja = f'/static/img/{filename}'

	if form.validate_on_submit():
		if form.validate_on_submit():
			mc = mydb.cursor()
			mc.execute(f"INSERT INTO paketi VALUES(null, '{naziv}','{putanja}','{opis}','{cena}') ")
			mydb.commit()
			flash("Room added successfuly!")
			return redirect(url_for('admin_panel'))
		else:
			flash(f"Room number already exist")
		return redirect(url_for('admin_panel')) 
	return render_template('admin_panel.html', k=res,p=rez,t=trening,t2=trening2,form=form)




@app.route('/zakazi_paket',methods = ["POST"])
def zakazi_paket():
	form = zakazivanjeForm()
	t_id = request.form['t_id']
	if "usr" not in session:

		ime_korisnika = form.z_ime_prezime.data
		email = form.z_email.data
		telefon = form.z_telefon.data
		slika_korisnika = "/static/img/korisnici/default.png"
		mc = mydb.cursor()
		mc.execute(f"INSERT INTO zakazani_paketi VALUES(null, '{ime_korisnika}','{email}','{telefon}', '{t_id}') ")
		mydb.commit()
		flash("Uspesno ste odabrali paket")
	
		return redirect(url_for('index'))
	
	username = session['usr']

	mc = mydb.cursor()
	mc.execute(f"SELECT id FROM korpa WHERE korisnik_username = '{username}' AND paket_id = '{t_id}'")
	rez = mc.fetchall()

	if rez:
		flash('Vec ste odabrali ovaj paket!')
		return redirect(url_for('index'))

	mc.execute(f"INSERT INTO korpa VALUES(null, '{username}', '{t_id}') ")
	mydb.commit()

	flash('Odabrali ste paket')
	return redirect(url_for('index'))


@app.route('/obrisi/korisnika/<id>', methods=['POST', 'GET'])
def obrisi_korisnika(id):
	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM users WHERE id={id}")
	rez = mc.fetchall()
	mc = mydb.cursor()
	mc.execute(f"DELETE FROM users WHERE id={id}")
	mydb.commit()
	flash("Korisnik je izbrisan!")
	return redirect(url_for('admin_panel'))
		


@app.route('/obrisi/paket/<id>', methods=['POST', 'GET'])
def obrisi_paket(id):
	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM paketi WHERE id={id}")
	rez = mc.fetchall()
	mc = mydb.cursor()
	mc.execute(f"DELETE FROM paketi WHERE id={id}")
	mydb.commit()
	flash("Paket je obrisan!")
	return redirect(url_for('admin_panel'))



@app.route('/obrisi/trening/<id>', methods=['POST', 'GET'])
def obrisi_trening(id):
	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM korpa WHERE id={id}")
	rez = mc.fetchall()
	mc = mydb.cursor()
	mc.execute(f"DELETE FROM korpa WHERE id={id}")
	mydb.commit()
	flash("Zakazani paket je obrisan!")
	return redirect(url_for('admin_panel'))

@app.route('/obrisi/trening2/<id>', methods=['POST', 'GET'])
def obrisi_trening2(id):
	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM zakazani_paketi WHERE id={id}")
	rez = mc.fetchall()
	mc = mydb.cursor()
	mc.execute(f"DELETE FROM zakazani_paketi WHERE id={id}")
	mydb.commit()
	flash("Zakazani paket je obrisan!")
	return redirect(url_for('admin_panel'))


@app.route('/otkazi/paket/<id>', methods=['POST', 'GET'])
def otkazi_paket(id):
	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM korpa WHERE id={id}")
	rez = mc.fetchall()
	mc = mydb.cursor()
	mc.execute(f"DELETE FROM korpa WHERE id={id}")
	mydb.commit()
	flash("Izabrani paket je otkazan!")
	return redirect(url_for('profil', username = session['usr']))


@app.route('/profil/<username>', methods=['POST', 'GET'])
def profil(username):

	if "usr" not in session:
		if "admin" not in session:
			flash("Morate da se ulogujete")
		
			return redirect(url_for('index')) 
	
	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM users WHERE username='{username}'")
	korisnik = mc.fetchall()
	
	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM korpa WHERE korisnik_username='{username}'")
	rez = mc.fetchall()

	mc = mydb.cursor()
	mc.execute(f"SELECT korpa.id ,korpa.korisnik_username, paketi.naziv,paketi.opis,paketi.cena FROM korpa LEFT JOIN paketi ON korpa.paket_id = paketi.id WHERE korisnik_username='{username}'")
	proba = mc.fetchall()
	
	if request.method == 'POST':
		ime = request.form['ime']
		email = request.form['email']
		godina = request.form['godina']
		telefon = request.form['telefon']
		
		mc = mydb.cursor()
		mc.execute(f"UPDATE users SET ime_prezime='{ime}', email='{email}' ,godina_rodjenja='{godina}', telefon='{telefon}' WHERE username='{username}'")
		mydb.commit()

		flash("Uspesno ste izmenili podatke")
		return redirect(request.url)
	
	return render_template("profil.html",podaci =rez,k =korisnik[0] , proba = proba)


@app.route('/kontakt', methods=['POST'])
def kontakt():
	ime = request.form['ime_prezime']
	email = request.form['email']
	poruka = request.form['poruka']
	
	if ime and email and poruka:
		msg = Message(
			subject="Kontakt",
			sender=app.config.get("MAIL_USERNAME"),
			recipients=[app.config.get("MAIL_USERNAME")]
		)

		msg.html = '<b>Teretana kontakt <br/><br/>Name:</b> ' + ime + '<br/>' + '<b>Email:</b> ' + email + '<br/>' + '<b>Message:</b><br/>' + poruka
		mail.send(msg)
		return jsonify({'poruka' : 'uspesno'})
	
	return jsonify({'error' : 'greska'})


@app.route('/vratiTermin', methods=['POST'])
def vratiTermin():
	id = request.form["id"]

	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM paketi WHERE id='{id}'")
	rez = mc.fetchall()

	return jsonify({
		'termin' : rez
	})

	
if __name__ == '__main__':
	app.run(debug=True)