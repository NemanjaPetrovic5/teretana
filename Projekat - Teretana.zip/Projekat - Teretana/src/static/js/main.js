$(document).ready(function() {
	setTimeout(function() {
		$('.poruke').fadeOut('slow');
	}, 3000);
});

$(document).ready(function ()
{

    $("#zakazivanje_prozor").click(function() {
        $('#zakazivanje_prozor').hide();
        $('#rezervisi').hide();
    });

	$(".zakazi").click(function() {
		
		var termin_id = $(this).parent().parent().attr("trening_id");
		console.log("ID je " + termin_id);
		
		$.ajax({
			data : {
				id : termin_id
			},
			type : 'POST',
			url : '/vratiTermin'
		})
		.done(function(data) {
			$('#zakazivanje_prozor').show();

			$('#rezervisi #termin_id').attr("value", data.termin[0][0]);
			$('#rezervisi #termin_naziv').text(data.termin[0][1]);
			$('#rezervisi #termin_opis').text(data.termin[0][3]);
			$('#rezervisi #termin_cena').text(data.termin[0][4]);

			$('#rezervisi').show();
			
		});

	});

});

$(document).ready(function() {
	$(".mob_btn").click(function() {
		$(".nav_mob").toggleClass('mob_klasa');
	});
	$(".nav_mob a").click(function() {
		$(".nav_mob").toggleClass('mob_klasa');
	});
	$(".ime").click(function() {
		$(".ulogovan").toggleClass('mob_klasa');
	});
});

$(document).ready(function() {
    $('#pretraga').keyup(function() {
        search_table($(this).val(), $('#tabela_paketi tr'));
    })
    
    function search_table(txt, tabela) {
        tabela.each(function() {
            $(this).each(function() {
                if($(this).text().toLowerCase().indexOf(txt.toLowerCase()) >= 0) 
                {
                    $(this).show();
                }
                else 
                {
                    $(this).hide();
                }
            });
        });
        
	}
});

$(document).ready(function()
{
	$('#forma_kontakta').on('submit', function(event) {
		var ime_pre = $('#ime_prezime').val();
		var mail = $('#email').val();
		var por = $('#poruka').val();
		console.log(por + "" + mail);
		$('#forma_kontakta').css('display', 'none')
		$('.salje_se').css('display', 'block')
		$.ajax({
			data : {
				ime_prezime : ime_pre,
				email : mail,
				poruka : por
			},
			type : 'POST',
			url : '/kontakt',
			dataType : 'json'
		})
		.done(function(data) {
			if(data.error) {
				$('.salje_se').css('display', 'none')
				$('.greska').css('display', 'block')
			}
			else {
				$('.salje_se').css('display', 'none')
				$('.uspesno').css('display', 'block')
			}
		});
		event.preventDefault();
	});
});